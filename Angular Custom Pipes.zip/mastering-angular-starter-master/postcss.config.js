module.exports = {
    plugins: [ require('autoprefixer') ],
    sourceMap: false,
};