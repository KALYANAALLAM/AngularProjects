'use strict';

// lists the web browsers to use for unit testing
module.exports = {
    'Local_Phantom': {
        base: 'PhantomJS'
    }
};